import java.io.IOException;
import java.sql.SQLException;

import data.Data;
import data.TrainingDataException;

import tree.RegressionTree;
import server.UnknownValueException;
import utility.Keyboard;

public class MainTest5 {

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException{
		
		
		
		int decision=0; 
		do{
		
			System.out.println("Apprendo l'albero di regressione [1]");//
			System.out.println("Carica l'albero di regressione [2]");
			decision=Keyboard.readInt();
		}while(!(decision==1) && !(decision ==2));
		
		String trainingfileName="";   
		System.out.println("File name:");
		trainingfileName=Keyboard.readString(); 
		 
		RegressionTree tree=null;
		if(decision==1)
		{
			System.out.println("Avvio della fase di acquisizione dei dati!");
			Data trainingSet=null;
			try{
			
				trainingSet= new Data(trainingfileName);
			}
			catch(TrainingDataException e){System.out.println(e);return;}
		
			System.out.println("Avvio della fase di apprendimento!");
			tree=new RegressionTree(trainingSet);
			try {
				tree.salva(trainingfileName+".dmp"); 
			} catch (IOException e) {
				
				System.out.println(e.toString());
			}
		} else
 			try {
				tree=RegressionTree.carica(trainingfileName+".dmp");
			} catch (ClassNotFoundException | IOException e) {
				System.out.print(e);
				return;
			}
		/////////////////////////////////
			System.out.println(tree.printRules());
			tree.printTree();
			
			char risp='y';
			do{
				System.out.println("Avvio della fase di previsione!");
				try {
					System.out.println(tree.predictClass());
				} catch (UnknownValueException e) {
					
					System.out.println(e); 
				}
				System.out.println("Vuoi ripetere ? (y/n)");
				risp=Keyboard.readChar();
				
			}while (Character.toUpperCase(risp)=='Y');
		
			System.out.println("Arrivederci");			
	}  

}
