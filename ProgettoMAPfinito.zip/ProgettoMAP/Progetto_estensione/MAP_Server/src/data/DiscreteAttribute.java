package data;
import java.io.Serializable;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;
/**
 * Estende la classe Attribute e rappresenta un attributo discreto
 * @author Daniele Lovecchio, Giuseppe Alaimo, Luigi Fragale
 *
 */
public class DiscreteAttribute extends Attribute implements Iterable<String>, Serializable{			
	//ATTRIBUTI
	/**
	 * Set di oggetti String, uno per ciascun valore discreto che l'attributo pu� assumere
	 */
	private Set<String> values=new TreeSet<>(); 
	
	//METODI
	/**
	 *  Invoca il costruttore della superclasse e avvalora il Set values con i valori
	 *  discreti in input 
	 * @param name
	 * @param index
	 * @param values
	 */
	public DiscreteAttribute(String name, int index, Set<String> values) {
		super(name,index);
		this.values=values;
	}
	
	
	/**
	 * Ritorna il numero di valori discreti (cardinalit� di values)
	 * @return values.length
	 */
	public int getNumberOfDistinctValues(){		
		return values.size(); 			
	}
	/**
	 * Iteratore (di tipo String) del Set values
	 * @return values.iterator()
	 */
	@Override
	public Iterator<String> iterator() {
		return values.iterator();
	}
	
	/**
	 * Il metodo toString di Attribute (superclasse)
	 * @return String
	 */
	public String toString(){			
		return super.toString();		
		 									
	}
}//fine classe
