package data;

/**
 * Classe per gestire il caso di acquisizione errata del Training set 
 * (file inesistente, schema mancante, training set vuoto o training set privo di variabile target numerico)
 * @author Daniele Lovecchio, Giuseppe Alaimo, Luigi Fragale
 *
 */
@SuppressWarnings("serial")
public class TrainingDataException extends Exception{
	/**
	 * Costruttore senza parametri : viene richiamato il costruttore di Exception 
	 * e viene passato il messsaggio "Training Data Exception".
	 */
	public TrainingDataException(){
		super("Training Data Exception");
	}
	
	/**
	 * Costruttore : viene richiamato il costruttore di Exception 
	 * e viene passato il messaggio indicato come parametro.
	 * @param message
	 */
	public TrainingDataException(String message){
		super(message+"\n");
	}

}
