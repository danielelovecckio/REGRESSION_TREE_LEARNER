package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author Daniele Lovecchio, Giuseppe Alaimo, Luigi Fragale
 */
public class MultiServer{
	//ATTRIBUTI
	private int PORT;

	//METODI
	/**
	 * Inizializza la porta ed invoca il metodo run()
	 * @param PORT
	 */
	public MultiServer(int PORT) {
		this.PORT=PORT;
		run();
	}
	/**
	 * Istanzia un oggetto istanza della classe ServerSocket che pone in attesa di crichiesta di connessioni da parte del client. 
	 * Ad ogni nuova richiesta connessione si istanzia ServerOneClient.
	 */
    private void run()  {                                
        System.out.println("Server in ascolto ...");
        ServerSocket serverSocket=null;
        try {
            serverSocket = new ServerSocket(PORT);

        while (true) {
                Socket socket = serverSocket.accept();
                new ServerOneClient(socket);
        }

        } catch (IOException e) {
            System.out.println("Errore durante l'accettazione del client");

        }finally {
            System.out.println("Chiusura");
            try {
                serverSocket.close();
            }catch(IOException e) {
                System.out.println("Socket non chiusa");
            }
        }
    }


}

