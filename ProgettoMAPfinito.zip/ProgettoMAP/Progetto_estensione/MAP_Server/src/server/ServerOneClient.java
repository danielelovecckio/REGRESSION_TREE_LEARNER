package server;

import java.io.*;
import java.net.*;

import java.sql.SQLException;

import data.Data;
import data.TrainingDataException;
import tree.*;
import tree.RegressionTree;


/**
 * La classe estende la classe Thread e si occupa della gestione delle richieste di un singolo client
 * @author Daniele Lovecchio, Giuseppe Alaimo, Luigi Fragale
 */
public class ServerOneClient extends Thread {
	//ATTRIBUTI
	private Socket socket; 
	private ObjectInputStream in=null; 
	private ObjectOutputStream out=null;

	//METODI
	/**
	 * Costruttore di classe. Inizializza gli attributi socket, in e out. Avvia il thread con il metodo start().
	 * @param socket
	 * @throws IOException
	 */
	public ServerOneClient(Socket socket) throws IOException{
		this.socket=socket;
		String socketName=socket.getInetAddress().getHostName();
		System.out.println("Connessione stabilita "+socketName+" con porta"+socket.getPort());
		out = new ObjectOutputStream(socket.getOutputStream());
		in = new ObjectInputStream(socket.getInputStream());
		System.out.println("Client: "+" "+socketName);
		start();
	}
	/**
	 * override del metodo run della superclasse Thread al fine di gestire le richieste del client.
	 */
	public void run(){
		RegressionTree tree=new RegressionTree();
		Integer val=null;
		Data trainingSet=null;
		String nomeTabella=null;
		try {
			val=Integer.valueOf(in.readObject().toString());
			if(val==0) {
				nomeTabella=in.readObject().toString();
				out.writeObject("OK");
				val=Integer.valueOf(in.readObject().toString());
				/*try {
					trainingSet = new Data(nomeTabella);
				}catch(TrainingDataException e) {
					System.err.println(e.getMessage());
					out.writeObject(e.getMessage());	
				}*/
				trainingSet = new Data(nomeTabella);
				tree=new RegressionTree(trainingSet);
				if(val==1) {
					tree.salva(nomeTabella+".dmp"); 
				}
				
			}else if(val==2) {
					nomeTabella=in.readObject().toString();							
					tree=RegressionTree.carica(nomeTabella+".dmp");
			}
			out.writeObject("OK");
			val=Integer.valueOf(in.readObject().toString());
			
			if(val==3) {
				
				String risp="y";
				do{
					risp="y";
					try {
						out.writeObject(predictClass(tree));
					} catch (UnknownValueException e) {
						out.writeObject(e.getMessage());	//invio messaggio di errore al client fuori range
					}
					
					try {
						risp=in.readObject().toString();
					}catch(EOFException | SocketException e) {
						risp="4";
						socket.close();	
						in.close();
						out.close();
					}
					
			}while (risp.equalsIgnoreCase("3"));
		
			}				
		} catch (ClassNotFoundException | IOException e) {
			System.err.println(e.getMessage());
			try {
				out.writeObject(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} catch (InstantiationException e) {
			System.err.println(e.getMessage());
		} catch (IllegalAccessException e) {
			System.err.println(e.getMessage());
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		} catch (TrainingDataException e) {
			System.err.println(e.getMessage());
			try {
				out.writeObject(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

  }
	
	/**
	  * Visualizza le informazioni di ciascuno split dell'albero (SplitNode.formulateQuery()) 
	  * e per il corrispondente attributo acquisisce il  valore dell'esempio da predire da tastiera. 
	  * Se il nodo root corrente � leaf  termina l'acquisizione e visualizza la predizione per l�attributo classe, 
	  * altrimenti invoca ricorsivamente  sul figlio di root in childTree individuato dal valore acquisito da tastiera. 
	  *	Il metodo sollevare l'eccezione UnknownValueException qualora la risposta dell�utente non permetta di selezionare
	  * un ramo valido del nodo di split.
	  * L'eccezione sar� gestita nel metodo che invoca predictClass(). 
	  *
	  * @return Double
	  * @throws UnknownValueException
	  * @throws ClassNotFoundException
	  * @throws IOException
	  */
	private Double predictClass(RegressionTree tree) throws UnknownValueException, ClassNotFoundException, IOException{
	      if(tree.getRoot() instanceof LeafNode) {
	        	out.writeObject("OK");
	            return ( (LeafNode)tree.getRoot() ).getPredictedClassValue();
	        
	        }else
	        {
	        	out.writeObject("QUERY");
	            int choice;
	            out.writeObject( ((SplitNode)tree.getRoot()).formulateQuery() );
	            choice = ((Integer)in.readObject()).intValue();
	        
	             int max = ((SplitNode) tree.getRoot()).getNumberOfChildren();
	            if( choice < 0 || choice >= max ) {
	                throw new UnknownValueException("La risposta � fuori range");
	            }else {
	                return predictClass( tree.getChildTree(choice) );
	            }   
	        }
	    }


	
}

