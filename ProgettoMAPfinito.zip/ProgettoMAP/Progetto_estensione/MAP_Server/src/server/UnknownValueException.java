package server;

/**
 * Classe per gestire il caso di acquisizione di valore mancante o fuori range
 * di un attributo di un nuovo esempio da classificare. 
 * 
 * @author Daniele Lovecchio, Giuseppe Alaimo, Luigi Fragale
 *
 */
@SuppressWarnings("serial")
public class UnknownValueException extends Exception {
	/**
	 * Costruttore senza parametri : viene richiamato il costruttore di Exception 
	 * e viene passato il messsaggio "Valore mancante o fuori range".
	 */
	public UnknownValueException(){
		 super("Valore mancante o fuori range");
	 }
	
	/**
	 * Costruttore : viene richiamato il costruttore di Exception 
	 * e viene passato il messaggio indicato come parametro.
	 * @param message
	 */
	public  UnknownValueException(String message){
		 super(message+"\n");
	 }
}
