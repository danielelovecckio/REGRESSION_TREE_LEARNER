import server.*; 
/**
 *	Classe Main del server :
 *	Viene creato un oggetto multiserver che permette di gestire pi� client
 * @author Daniele Lovecchio, Giuseppe Alaimo, Luigi Fragale
 */
class MainServer { 
  
	/**    
	 * @param args
	 */ 
	public static void main(String[] args) {
			@SuppressWarnings("unused")
			MultiServer multiServer = new MultiServer(8080); 
	}

}
