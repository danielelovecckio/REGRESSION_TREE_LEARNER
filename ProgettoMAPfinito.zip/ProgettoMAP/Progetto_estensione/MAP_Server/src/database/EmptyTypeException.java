package database;

/**
 * Modella l'eccezione di tipo errato
 * @author Daniele Lovecchio, Giuseppe Alaimo, Luigi Fragale
 */
@SuppressWarnings("serial")
public class EmptyTypeException extends Exception{
	/**
	 * Costruttore senza parametri : viene richiamato il costruttore di Exception 
	 * e viene passato il messsaggio "Empty Type Exception".
	 */
	public EmptyTypeException() {
		super("Empty Type Exception");
	}
	/**
	 * Costruttore : viene richiamato il costruttore di Exception 
	 * e viene passato il messaggio indicato come parametro.
	 * @param e
	 */
	public EmptyTypeException(String e) {
		super(e);
	}
	
}
