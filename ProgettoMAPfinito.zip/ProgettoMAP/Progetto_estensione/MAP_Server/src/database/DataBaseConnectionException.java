package database;

/**
 * Modella l'eccezione di fallimento nella connessione al database
 * @author Daniele Lovecchio, Giuseppe Alaimo, Luigi Fragale
 */
public class DataBaseConnectionException extends Exception {
	/**
	 * Costruttore senza parametri : viene richiamato il costruttore di Exception 
	 * e viene passato il messsaggio "Errore di connessione al database".
	 */
	public DataBaseConnectionException() {
		super("Errore di connessione al database");
	}
	/**
	 * Costruttore : viene richiamato il costruttore di Exception 
	 * e viene passato il messaggio indicato come parametro.
	 * @param e
	 */
	public DataBaseConnectionException(String e) {
		super(e);
	}
}
