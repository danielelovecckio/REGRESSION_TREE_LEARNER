package database;

/**
 *	Modella l'eccezione di resultSet vuoto
 *  @author Daniele Lovecchio, Giuseppe Alaimo, Luigi Fragale
 */
@SuppressWarnings("serial")
public class EmptySetException extends Exception {
	/**
	 * Costruttore senza parametri : viene richiamato il costruttore di Exception 
	 * e viene passato il messsaggio "ResultSet vuoto".
	 */
	public  EmptySetException() {
		super("ResultSet vuoto");
	}
	/**
	 * Costruttore : viene richiamato il costruttore di Exception 
	 * e viene passato il messaggio indicato come parametro.
	 * @param e
	 */
	public  EmptySetException(String e) {
		super(e);
	}
}
