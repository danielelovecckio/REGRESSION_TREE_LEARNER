package database;
/**
 * Modella lo schema di una colonna all'interno di una tabella del database
 *	@author Daniele Lovecchio, Giuseppe Alaimo, Luigi Fragale
 */
public class Column {
		private String name;
		private String type;
		/**
		 * Costruttore : crea oggetto Column
		 * @param name 	nome della colonna
		 * @param type 	tipo della colonna 
		 */
		Column(String name,String type){
			this.name=name;
			this.type=type;
		}
		/**
		 * Restituisce il nome della colonna
		 * @return name
		 */
		public String getColumnName(){
			return name;
		}
		/**
		 * Verifica che la colonna sia di tipo numerico
		 * @return boolean
		 */
		public boolean isNumber(){
			return type.equals("number");
		}
		/**
		 * @return String
		 */
		public String toString(){
			return name+":"+type;
		}
	}

