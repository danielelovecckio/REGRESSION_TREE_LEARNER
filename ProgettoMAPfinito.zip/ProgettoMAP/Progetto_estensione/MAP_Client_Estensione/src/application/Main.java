package application;
	
import java.io.IOException;

import javafx.application.Application; 
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;
  
/** 
 *  
 * @author Daniele Lovecchio, Giuseppe Alaimo, Luigi Fragale  
 */
public class Main extends Application {
	private static String nomeFile = "Sample.fxml";
	@Override
	public void start(Stage primaryStage) {
		try {
			Parent root =FXMLLoader.load(getClass().getResource(nomeFile));
			Scene scene = new Scene(root,800,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show(); 
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		try {
			SampleController.connection(new Integer(args[1]),args[0]);
		} catch (IOException e) {
			nomeFile="erroreConnessione.fxml";
		}
		launch(args);
	}
}
