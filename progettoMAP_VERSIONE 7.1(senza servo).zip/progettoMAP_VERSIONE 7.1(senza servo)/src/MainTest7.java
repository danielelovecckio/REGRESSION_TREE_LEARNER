import server.*;
/**
 * @author Daniele Lovecchio
 *
 */
public class MainTest7 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			MultiServer multiServer = new MultiServer(8080); 
	}

}
